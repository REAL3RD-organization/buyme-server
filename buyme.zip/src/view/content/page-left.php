<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 2/6/2016 006
 * Time: 4:27 PM
 */
?>
<div id="page-left">
    page right
</div>