<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 2/6/2016 006
 * Time: 3:50 PM
 */
?>
<div id="page-content">

    <?php for($i = 0; $i < 3; $i++) {?>
    <div class="page-content-row">
        <div class="pentry">
            <div class="pentry-left">
                photo
            </div>
            <div class="pentry-right">
                <div class="pentry-phrase">
                    <p>제일기획 인턴 출신입니다.</p>
                </div>
                <div class="pentry-name">
                    <p>유인영</p>
                </div>
                <div class="pentry-school">
                    <p>학교전공</p>
                </div>
                <div class="pentry-exp">
                    <p>경력</p>
                </div>
            </div>
        </div>
    </div>
        <?php
    }
    ?>
</div>

