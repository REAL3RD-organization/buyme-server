<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 2/6/2016 006
 * Time: 4:31 PM
 */
header("Content-Type: text/html; charset=utf-8");
ini_set("default_charset", 'utf-8');


?>
<div id="login">
    <form action="/" method="post" >
        id<input type="text"/>
        pwd<input type="text"/>
        <input type="submit" value="login">
    </form>

    
</div>
