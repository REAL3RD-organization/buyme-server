<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 2/6/2016 006
 * Time: 4:38 PM
 */?>
<div id="submit">
    <form action="" method="POST" enctype="multipart/form-data">
        이름 : <input type="text" name="name"></br>
        학력 : <input type="text" name="school"></br>
        전공 : <input type="text" name="major"></br>
        경력 : <input type="text" name="exp"></br>
        profile : <input type="file" name="img">
    </form>
</div>
