<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 2/6/2016 006
 * Time: 4:38 PM
 */?>
<div id="brand">
    <div id="brand-content">
        <div class="logo">
            <p>BUY ME</p>
        </div>
        <div class="sublogo">
            "자신을 표현하고 자신을 파세요."
        </div>
    </div>

</div>
