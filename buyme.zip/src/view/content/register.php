<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 2/6/2016 006
 * Time: 5:04 PM
 */




?>

<div id="register">

    <div class="register-type">
        <div class="register-person">person</div>
        <div class="register-company">company</div>
    </div>

    <div class="register-name">
        <p class="regitser-name-label">name</p>
        <input type="text" name="name"/>
    </div>
    <div class="register-nick">
        <p class="regitser-nick-label">nick name</p>
        <input type="text" name="nick"/>
    </div>
    <div class="register-email">
        <p class="regitser-email-label">email</p>
        <input type="text" name="email"/>
    </div>
    <div class="register-birth">
        <p class="regitser-birth-label">birth</p>
        <input type="text" name="birth"/>
    </div>
    <div class="register-cell">
        <p class="regitser-cell-label">cell</p>
        <input type="text" name="cell"/>
    </div>
</div>
