<?php
/**
 * Created by PhpStorm.
 * User: 도원
 * Date: 2016-02-06
 * Time: 오후 1:30
 */

echo 1;